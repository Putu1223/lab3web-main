# Lab3Web
Membuat List
Membuat ordered list 
![1](https://user-images.githubusercontent.com/81283969/114340005-c4837200-9b80-11eb-8134-1bc8fbf97125.png)
Hasil dari ordered list
![2](https://user-images.githubusercontent.com/81283969/114340103-fe547880-9b80-11eb-983e-413020afa511.png)
Membuat unorderd list
![3](https://user-images.githubusercontent.com/81283969/114340161-1fb56480-9b81-11eb-843c-967d74b6d1af.png)
Hasil dari unorderd list
![4](https://user-images.githubusercontent.com/81283969/114340190-33f96180-9b81-11eb-9f68-f6a6209965ea.png)
Mebuat description list
![5](https://user-images.githubusercontent.com/81283969/114340232-52f7f380-9b81-11eb-9655-34752098bd34.png)
Hasil dari description list
![6](https://user-images.githubusercontent.com/81283969/114340324-833f9200-9b81-11eb-8369-fbccdc4461cf.png)

Membuat Tabel
![1 1](https://user-images.githubusercontent.com/81283969/114340416-b71ab780-9b81-11eb-9d5a-266dae1a1d4d.png)
Hasil dari membuat tabel
![1 2](https://user-images.githubusercontent.com/81283969/114340463-d1549580-9b81-11eb-9df6-bbcc01d750cd.png)
Membuat tabel dan menggabungkan sel data
![1 3](https://user-images.githubusercontent.com/81283969/114340563-08c34200-9b82-11eb-8464-6872cf42b0f7.png)
![1 5](https://user-images.githubusercontent.com/81283969/114340796-8b4c0180-9b82-11eb-8bd9-e84e8308cc6c.png)
Hasil dari menggabungkan sel data
![1 4](https://user-images.githubusercontent.com/81283969/114340606-2b555b00-9b82-11eb-9973-ab1bf0958e76.png)
![1 6](https://user-images.githubusercontent.com/81283969/114340818-9a32b400-9b82-11eb-96bc-f4982cdc191d.png)

Membuat Form
![2 1](https://user-images.githubusercontent.com/81283969/114340860-ae76b100-9b82-11eb-867f-186272ebbc41.png)
Hasil dari membuat form
![2 2](https://user-images.githubusercontent.com/81283969/114340881-bd5d6380-9b82-11eb-8814-a8ab9c053a46.png)
Menambahkan style pada form
![2 3](https://user-images.githubusercontent.com/81283969/114340909-cbab7f80-9b82-11eb-98e7-1085a85578c3.png)
Hasil style pada form
![2 4](https://user-images.githubusercontent.com/81283969/114340930-d9f99b80-9b82-11eb-8f0a-e8c86dadad27.png)


